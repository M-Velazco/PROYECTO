-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-09-2023 a las 05:13:20
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `crud`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nombre` text NOT NULL,
  `apellidos` text NOT NULL,
  `telefono` mediumint(9) NOT NULL,
  `correo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `nombre`, `apellidos`, `telefono`, `correo`) VALUES
(1, 'pepito', 'Flores Martin', 8388607, 'pepito@gmail.com'),
(5, 'sofiaa', 'martinez', 7756534, 'luisamartinez@gmail.com'),
(12, 'luis', 'mendoza', 6875323, 'luisameb@gmail.com'),
(34, 'karen', 'aguirre', 257351, 'karenarit@gmail.com'),
(46, 'sandra', 'calcedo', 38972, 'calcedosandra42@hotmail.co'),
(53, 'vanesa', 'castro', 377784, 'castrovane@hotmail.com'),
(54, 'andres', 'silva ', 1357283, 'andreslis@gmail.com'),
(63, 'maicol', 'daza', 7276456, 'dazamaicol@hotmail.com'),
(71, 'yohana', 'mosquera', 324466, 'yohana27mosque@hotmail.com'),
(75, 'paula ', 'barragan ', 776243, 'barraganpau@gmail.com'),
(97, 'Sebastián ', 'ortega', 113681, 'ortega1673@gmail.com'),
(98, 'lorena', 'mendez', 864283, 'mendez23lore@gmail.com'),
(131, 'johan ', 'roa', 3671513, 'roajohan1@gmail.com'),
(643, 'karol', 'gomez', 8863, 'karolgomes173@gmail.com'),
(863, 'leandro', 'loice', 38254, 'loicelena73@gmail.com');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=864;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
